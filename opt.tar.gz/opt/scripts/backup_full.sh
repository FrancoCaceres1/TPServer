mostrar_ayuda() {
	echo "uso: $0 <origen> <destino>"
	echo "ejemplo: $0 /var/logs /backup_dir"
	exit 0
}

if [ "$1" == "-h" ]; then
	mostrar_ayuda
fi

if [ "$#" -ne 2 ]; then 
	echo "uso: $0 <origen> <destino>"
	exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$DESTINO" ] || [ ! -d "$DESTINO" ]; then
	echo "El destino no esta montado"
	exit 1
fi

FECHA+$(date +%Y%m%d)

case "$ORIGEN" in
	/var/logs)
		ARCHIVO="$DESTINO/var_logs_bkp_$FECHA.tar.gz"
		;;
	/www_dir)
		ARCHIVO="$DESTINO/www_dir_bkp_$FECHA.tar.gz"
		;;
	*)
		echo "directorio de origen no soportado"
		exit 1
		;;
esac

if tar -czf "$ARCHIVO" "$ORIGEN"; then
	echo "backup de $ORIGEN realizado con exito en $ARCHIVO"
else
	echo "error al crear el backup de $ORIGEN"
	exit 1
fi 
